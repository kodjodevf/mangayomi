var aniyomi = require('./init_aniyomi_functions');

function set_anime_a() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_S.glsl")
	mp.command("show-text \"Anime4K: Mode A (Fast)\"")
	set_selected_shader("Anime4K: Mode A (Fast)")
}

function set_anime_b() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_S.glsl")
	mp.command("show-text \"Anime4K: Mode B (Fast)\"")
	set_selected_shader("Anime4K: Mode B (Fast)")
}

function set_anime_c() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Upscale_Denoise_CNN_x2_M.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_S.glsl")
	mp.command("show-text \"Anime4K: Mode C (Fast)\"")
	set_selected_shader("Anime4K: Mode C (Fast)")
}

function set_anime_aa() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl;~~/shaders/Anime4K_Restore_CNN_S.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_S.glsl")
	mp.command("show-text \"Anime4K: Mode A+A (Fast)\"")
	set_selected_shader("Anime4K: Mode A+A (Fast)")
}

function set_anime_bb() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_S.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_S.glsl")
	mp.command("show-text \"Anime4K: Mode B+B (Fast)\"")
	set_selected_shader("Anime4K: Mode B+B (Fast)")
}

function set_anime_ca() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Upscale_Denoise_CNN_x2_M.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Restore_CNN_S.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_S.glsl")
	mp.command("show-text \"Anime4K: Mode C+A (Fast)\"")
	set_selected_shader("Anime4K: Mode C+A (Fast)")
}

function set_anime_hq_a() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl")
	mp.command("show-text \"Anime4K: Mode A (HQ)\"")
	set_selected_shader("Anime4K: Mode A (HQ)")
}

function set_anime_hq_b() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl")
	mp.command("show-text \"Anime4K: Mode B (HQ)\"")
	set_selected_shader("Anime4K: Mode B (HQ)")
}

function set_anime_hq_c() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Upscale_Denoise_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl")
	mp.command("show-text \"Anime4K: Mode C (HQ)\"")
	set_selected_shader("Anime4K: Mode C (HQ)")
}

function set_anime_hq_aa() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_Restore_CNN_M.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl")
	mp.command("show-text \"Anime4K: Mode A+A (HQ)\"")
	set_selected_shader("Anime4K: Mode A+A (HQ)")
}

function set_anime_hq_bb() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl")
	mp.command("show-text \"Anime4K: Mode B+B (HQ)\"")
	set_selected_shader("Anime4K: Mode B+B (HQ)")
}

function set_anime_hq_ca() {
    mp.set_property("glsl-shaders", "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Upscale_Denoise_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Restore_CNN_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl")
	mp.command("show-text \"Anime4K: Mode C+A (HQ)\"")
	set_selected_shader("Anime4K: Mode C+A (HQ)")
}

function set_fsr() {
    mp.set_property("glsl-shaders", "~~/shaders/FSR.glsl")
	mp.command("show-text \"AMD FSR\"")
	set_selected_shader("AMD FSR")
}

function set_luma() {
    mp.set_property("glsl-shaders", "~~/shaders/ArtCNN_C4F16.glsl;~~/shaders/CfL_Prediction.glsl")
	mp.command("show-text \"Luma Upscaling\"")
	set_selected_shader("Luma Upscaling")
}

function set_snapdragon() {
    mp.set_property("glsl-shaders", "~~/shaders/SGSR.glsl")
	mp.command("show-text \"Q Snapdragon GSR\"")
	set_selected_shader("Q Snapdragon GSR")
}

function set_nvidia() {
    mp.set_property("glsl-shaders", "~~/shaders/NVScaler.glsl")
	mp.command("show-text \"NVIDIA Image Scaling\"")
	set_selected_shader("NVIDIA Image Scaling")
}

function clear_anime() {
    mp.set_property("glsl-shaders", "")
	mp.command("show-text \"GLSL shaders cleared\"")
	set_selected_shader("")
}

function set_selected_shader(text) {
	mp.set_property("user-data/mangayomi/selected_shader", text)
}

mp.register_script_message("set_anime_a", set_anime_a)
mp.register_script_message("set_anime_b", set_anime_b)
mp.register_script_message("set_anime_c", set_anime_c)
mp.register_script_message("set_anime_aa", set_anime_aa)
mp.register_script_message("set_anime_bb", set_anime_bb)
mp.register_script_message("set_anime_ca", set_anime_ca)
mp.register_script_message("set_anime_hq_a", set_anime_hq_a)
mp.register_script_message("set_anime_hq_b", set_anime_hq_b)
mp.register_script_message("set_anime_hq_c", set_anime_hq_c)
mp.register_script_message("set_anime_hq_aa", set_anime_hq_aa)
mp.register_script_message("set_anime_hq_bb", set_anime_hq_bb)
mp.register_script_message("set_anime_hq_ca", set_anime_hq_ca)
mp.register_script_message("set_fsr", set_fsr)
mp.register_script_message("set_luma", set_luma)
mp.register_script_message("set_snapdragon", set_snapdragon)
mp.register_script_message("set_nvidia", set_nvidia)
mp.register_script_message("clear_anime", clear_anime)
