local utils = require 'mp.utils'

function get_chapter_titles()
	local count = mp.get_property_number("chapter-list/count")
	local chapters = {}
	for i = 1,count,1 do
		local title = mp.get_property_native("chapter-list/" .. (i - 1) .. "/title")
		local timestamp = mp.get_property_native("chapter-list/" .. (i - 1) .. "/time")
		print(title .. " - " .. timestamp)
		chapters[i] = {["title"] = title, ["timestamp"] = timestamp}
	end
	print(#chapters)
	mp.set_property("user-data/mangayomi/chapter_titles", utils.format_json(chapters))
end

function on_chapter_change(name, value)
	if value ~= nil then
		mp.set_property_number("user-data/mangayomi/current_chapter", value)
	end
end

mp.register_event("file-loaded", get_chapter_titles)
mp.observe_property("chapter", "number", on_chapter_change);
