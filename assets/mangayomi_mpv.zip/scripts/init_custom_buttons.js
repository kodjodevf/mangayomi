var aniyomi = require('./init_aniyomi_functions');function update_button(_, length) {
	if (length && length == 0) {
		aniyomi.hide_button()
	} else {
		aniyomi.show_button()
	}
	aniyomi.set_button_title("+" + length + " s")
}
if (true) {
  mp.observe_property("user-data/current-anime/intro-length", "number", update_button)
}
function button1() {
  var intro_length = mp.get_property("user-data/current-anime/intro-length")
aniyomi.right_seek_by(intro_length)
}
mp.register_script_message('call_button_1', button1)
function button1long() {
  aniyomi.int_picker("Change intro length", "%ds", 0, 255, 1, "user-data/current-anime/intro-length")
}
mp.register_script_message('call_button_1_long', button1long)
function button4() {
  aniyomi.seek_to(60)
}
mp.register_script_message('call_button_4', button4)
function button4long() {
  
}
mp.register_script_message('call_button_4_long', button4long)