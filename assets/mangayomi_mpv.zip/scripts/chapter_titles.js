var aniyomi = require('./init_aniyomi_functions');

function get_chapter_titles() {
	var count = mp.get_property_number("chapter-list/count")
	var chapters = []
	for (var i = 0; i < count; i++) {
		var title = mp.get_property_native("chapter-list/" + i + "/title")
		var time = mp.get_property_native("chapter-list/" + i + "/time")
		chapters.push({'title': title, 'time': time});
	}
	mp.set_property("user-data/mangayomi/chapter_titles", JSON.stringify(chapters))
}

function on_chapter_change(name, value) {
    mp.set_property_number("user-data/mangayomi/current_chapter", value);
}

mp.register_event("file-loaded", get_chapter_titles)
mp.observe_property("chapter", "number", on_chapter_change);
