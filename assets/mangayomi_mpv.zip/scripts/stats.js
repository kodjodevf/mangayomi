var utils = mp.utils;
var input = mp.input;

utils.format_bytes_humanized = function (b) {
    var sizeUnits = ["Bytes", "KiB", "MiB", "GiB", "TiB", "PiB"];
    var index = 0;
    while (b >= 1024) {
        b = b / 1024;
        index++;
    }
    return b.toFixed(2) + " " + (sizeUnits[index] ? sizeUnits[index] : "*1024^" + (index - 1));
}

var entries = function (obj) {
    var ownProps = Object.keys(obj),
      i = ownProps.length,
      resArray = new Array(i); // preallocate the Array

    while (i--) resArray[i] = [ownProps[i], obj[ownProps[i]]];
    return resArray;
};

if (!Object.entries)
  Object.entries = entries;

if (!Array.from) {
  Array.from = (function () {
    var toStr = Object.prototype.toString;
    var isCallable = function (fn) {
      return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
    };
    var toInteger = function (value) {
      var number = Number(value);
      if (isNaN(number)) { return 0; }
      if (number === 0 || !isFinite(number)) { return number; }
      return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
    };
    var maxSafeInteger = Math.pow(2, 53) - 1;
    var toLength = function (value) {
      var len = toInteger(value);
      return Math.min(Math.max(len, 0), maxSafeInteger);
    };

    // The length property of the from method is 1.
    return function from(arrayLike/*, mapFn, thisArg */) {
      // 1. Let C be the this value.
      var C = this;

      // 2. Let items be ToObject(arrayLike).
      var items = Object(arrayLike);

      // 3. ReturnIfAbrupt(items).
      if (arrayLike == null) {
        throw new TypeError("Array.from requires an array-like object - not null or undefined");
      }

      // 4. If mapfn is undefined, then let mapping be false.
      var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
      var T;
      if (typeof mapFn !== 'undefined') {
        // 5. else
        // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
        if (!isCallable(mapFn)) {
          throw new TypeError('Array.from: when provided, the second argument must be a function');
        }

        // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
        if (arguments.length > 2) {
          T = arguments[2];
        }
      }

      // 10. Let lenValue be Get(items, "length").
      // 11. Let len be ToLength(lenValue).
      var len = toLength(items.length);

      // 13. If IsConstructor(C) is true, then
      // 13. a. Let A be the result of calling the [[Construct]] internal method of C with an argument list containing the single item len.
      // 14. a. Else, Let A be ArrayCreate(len).
      var A = isCallable(C) ? Object(new C(len)) : new Array(len);

      // 16. Let k be 0.
      var k = 0;
      // 17. Repeat, while k < len… (also steps a - h)
      var kValue;
      while (k < len) {
        kValue = items[k];
        if (mapFn) {
          A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
        } else {
          A[k] = kValue;
        }
        k += 1;
      }
      // 18. Let putStatus be Put(A, "length", len, true).
      A.length = len;
      // 20. Return A.
      return A;
    };
  }());
}
if (!Array.isArray) {
  Array.isArray = function (arg) {
    return Object.prototype.toString.call(arg) === '[object Array]'
  }
}
if (!String.prototype.repeat) {
  String.prototype.repeat = function (count) {
    if (count < 1) return '';
    if (count % 2) return repeat(this, count - 1) + this;
    var half = repeat(this, count / 2);
    return half + half;
  }
}

function find(str, pattern, startingAt, plain) {
  if (!str) return [];
  startingAt = startingAt || 0;

  var needle;
  if (plain) {
    pattern = String(pattern);
    needle = str.slice(startingAt).indexOf(pattern);
  } else {
    needle = str.slice(startingAt || 0).match(pattern);
    needle = needle ? needle[0] : null;
  }

  if (!needle || needle === -1) {
    return [];
  }

  if (plain) {
    needle += startingAt;
    return [needle, needle + pattern.length];
  }

  var start = plain ? needle : str.slice(startingAt).indexOf(needle);

  start += startingAt;

  var end = plain ? start + pattern.length : start + needle.length;

  return [start, end];
}

function printf(str) {
  var args = Array.from(arguments);
  args.shift();
  var i = 0;
  function defaultNumber(iValue) {
    return iValue != undefined && !isNaN(iValue) ? iValue : "0";
  }
  function defaultString(iValue) {
    return iValue == undefined ? "" : "" + iValue;
  }
  return str.replace(
    /%%|%([+\-])?([^1-9])?(\d+)?(\.\d+)?([deEfhHioQqs])/g,
    function (match, sign, filler, scale, precision, type) {
      var strOut, space, value;
      var asNumber = false;
      if (match == "%%") return "%";
      if (i >= args.length) return match;
      value = args[i];
      while (Array.isArray(value)) {
        args.splice(i, 1);
        for (var j = i; value.length > 0; j++) args.splice(j, 0, value.shift());
        value = args[i];
      }
      i++;
      if (filler == undefined) filler = " "; // default
      if (scale == undefined && !isNaN(filler)) {
        scale = filler;
        filler = " ";
      }
      if (sign == undefined) sign = "sqQ".indexOf(type) >= 0 ? "+" : "-"; // default
      if (scale == undefined) scale = 0; // default
      if (precision == undefined) precision = ".0"; // default
      scale = parseInt(scale);
      precision = parseInt(precision.substring(1));
      switch (type) {
        case "d":
        case "i":
          // decimal integer
          asNumber = true;
          strOut = parseInt(defaultNumber(value));
          if (precision > 0) strOut += "." + "0".repeat(precision);
          break;
        case "e":
        case "E":
          // float in exponential notation
          asNumber = true;
          strOut = parseFloat(defaultNumber(value));
          if (precision == 0) strOut = strOut.toExponential();
          else strOut = strOut.toExponential(precision);
          if (type == "E") strOut = strOut.replace("e", "E");
          break;
        case "f":
          // decimal float
          asNumber = true;
          strOut = parseFloat(defaultNumber(value));
          if (precision != 0) strOut = strOut.toFixed(precision);
          break;
        case "o":
        case "h":
        case "H":
          // Octal or Hexagesimal integer notation
          strOut =
            "\\" +
            (type == "o" ? "0" : type) +
            parseInt(defaultNumber(value)).toString(type == "o" ? 8 : 16);
          break;
        case "q":
          // single quoted string
          strOut = "'" + defaultString(value) + "'";
          break;
        case "Q":
          // double quoted string
          strOut = '"' + defaultString(value) + '"';
          break;
        default:
          // string
          strOut = defaultString(value);
          break;
      }
      if (typeof strOut != "string") strOut = "" + strOut;
      if ((space = strOut.length) < scale) {
        if (asNumber) {
          if (sign == "-") {
            if (strOut.indexOf("-") < 0)
              strOut = filler.repeat(scale - space) + strOut;
            else
              strOut =
                "-" + filler.repeat(scale - space) + strOut.replace("-", "");
          } else {
            if (strOut.indexOf("-") < 0)
              strOut = "+" + filler.repeat(scale - space - 1) + strOut;
            else
              strOut =
                "-" + filler.repeat(scale - space) + strOut.replace("-", "");
          }
        } else {
          if (sign == "-") strOut = filler.repeat(scale - space) + strOut;
          else strOut = strOut + filler.repeat(scale - space);
        }
      } else if (asNumber && sign == "+" && strOut.indexOf("-") < 0)
        strOut = "+" + strOut;
      return strOut;
    }
  );
}

function IntervalTimer(callback, interval, periodic) {
  var timerId = 0;
  var startTime = 0;
  var remaining = 0;
  var state = 0; //  0 = idle, 1 = running, 2 = paused, 3= resumed

  this.timeout = interval;

  this.oneshot = !periodic;

  this.is_enabled = function() {
    return state != 0 && state != 2;
  }

  this.pause = function () {
    if (state != 1) return;

    remaining = (this.timeout * 1000) - (new Date() - startTime);
    if (this.oneshot) {
      clearTimeout(timerId);
    } else {
      clearInterval(timerId);
    }
    state = 2;
  };
  
  this.kill = function () {
    if (state != 1) return;

    startTime = 0;
    remaining = 0;
    if (this.oneshot) {
      clearTimeout(timerId);
    } else {
      clearInterval(timerId);
    }
    state = 2;
  };

  this.resume = function () {
    if (state != 2) return;

    state = 3;
    setTimeout(this.timeoutCallback, remaining);
  };

  this.timeoutCallback = function () {
    if (state != 3) return;

    callback();

    startTime = new Date();
    if (this.oneshot) {
      timerId = setTimeout(callback, this.timeout * 1000);
    } else {
      timerId = setInterval(callback, this.timeout * 1000);
    }
    state = 1;
  };

  startTime = new Date();
  if (this.oneshot) {
    timerId = setTimeout(callback, this.timeout * 1000);
  } else {
    timerId = setInterval(callback, this.timeout * 1000);
  }
  state = 1;
}











var o = {
  key_page_1: "1",
  key_page_2: "2",
  key_page_3: "3",
  key_page_4: "4",
  key_page_5: "5",
  key_page_0: "0",
  key_scroll_up: "UP",
  key_scroll_down: "DOWN",
  key_search: "/",
  key_exit: "ESC",
  scroll_lines: 1,
  duration: 4,
  redraw_delay: 1,
  ass_formatting: true,
  persistent_overlay: false,
  filter_params_max_length: 100,
  file_tag_max_length: 128,
  file_tag_max_count: 16,
  show_frame_info: false,
  term_clip: true,
  debug: false,
  plot_perfdata: false,
  plot_vsync_ratio: false,
  plot_vsync_jitter: false,
  plot_cache: true,
  plot_tonemapping_lut: false,
  skip_frames: 5,
  global_max: true,
  flush_graph_data: true,
  plot_bg_border_color: "0000FF",
  plot_bg_color: "262626",
  plot_color: "FFFFFF",
  plot_bg_border_width: 1.25,
  font: "",
  font_mono: "sans-serif",
  font_size: 20,
  font_color: "",
  border_size: 1.65,
  border_color: "",
  shadow_x_offset: Number.MAX_VALUE,
  shadow_y_offset: Number.MAX_VALUE,
  shadow_color: "",
  alpha: "11",
  vidscale: "auto",
  custom_header: "",
  ass_nl: "\\N",
  ass_indent: "\\h\\h\\h\\h\\h",
  ass_prefix_sep: "\\h\\h",
  ass_b1: "{\\b1}",
  ass_b0: "{\\b0}",
  ass_it1: "{\\i1}",
  ass_it0: "{\\i0}",
  no_ass_nl: "\n",
  no_ass_indent: "    ",
  no_ass_prefix_sep: " ",
  no_ass_b1: "\\027[1m",
  no_ass_b0: "\\027[0m",
  no_ass_it1: "\\027[3m",
  no_ass_it0: "\\027[0m",
  bindlist: "no",
};
var update_scale;
mp.options.read_options(o, undefined, function () {
  update_scale();
});
var format = printf;
var max = Math.max;
var min = Math.min;
var font_size = o.font_size;
var border_size = o.border_size;
var shadow_x_offset = o.shadow_x_offset;
var shadow_y_offset = o.shadow_y_offset;
var plot_bg_border_width = o.plot_bg_border_width;
var recorder = undefined;
var display_timer = undefined;
var cache_recorder_timer = undefined;
var curr_page = o.key_page_1;
var pages = [];
var scroll_bound = false;
var searched_text;
var tm_viz_prev = undefined;
var ass_start = mp.get_property_osd("osd-ass-cc/0");
var ass_stop = mp.get_property_osd("osd-ass-cc/1");
var vsratio_buf;
var vsjitter_buf;
function init_buffers() {
  vsratio_buf = { s: 0, pos: 1, len: 50, max: 0 };
  vsjitter_buf = { s: 0, pos: 1, len: 50, max: 0 };
}
var cache_ahead_buf;
var cache_speed_buf;
var perf_buffers = [];
var process_key_binding;
var property_cache = [];
function get_property_cached(name, def) {
  if (property_cache[name] !== undefined) {
    return property_cache[name];
  }
  return def;
}
function graph_add_value(graph, value) {
  graph.pos = (graph.pos % graph.len) + 1;
  graph[graph.pos] = value;
  graph.max = max(graph.max, value);
}
function no_ASS(t) {
  if (!o.use_ass) {
    return t;
  } else if (!o.persistent_overlay) {
    return ass_stop + (t + ass_start);
  } else {
    return mp.command_native(["escape-ass", String(t)]);
  }
}
function bold(t) {
  return o.b1 + (t + o.b0);
}
function it(t) {
  return o.it1 + (t + o.it0);
}
function text_style() {
  if (!o.use_ass) {
    return "";
  }
  if (o.custom_header && o.custom_header !== "") {
    return o.custom_header;
  } else {
    var style = "{\\r\\an7\\fs" + (font_size + ("\\bord" + border_size));
    if (o.font !== "") {
      style = style + ("\\fn" + o.font);
    }
    if (o.font_color !== "") {
      style =
        style + ("\\1c&H" + (o.font_color + ("&\\1a&H" + (o.alpha + "&"))));
    }
    if (o.border_color !== "") {
      style =
        style + ("\\3c&H" + (o.border_color + ("&\\3a&H" + (o.alpha + "&"))));
    }
    if (o.shadow_color !== "") {
      style =
        style + ("\\4c&H" + (o.shadow_color + ("&\\4a&H" + (o.alpha + "&"))));
    }
    if (o.shadow_x_offset < Number.MAX_VALUE) {
      style = style + ("\\xshad" + shadow_x_offset);
    }
    if (o.shadow_y_offset < Number.MAX_VALUE) {
      style = style + ("\\yshad" + shadow_y_offset);
    }
    return style + "}";
  }
}
function has_vo_window() {
  return (
    mp.get_property_native("vo-configured") &&
    mp.get_property_native("video-osd")
  );
}
function generate_graph(values, i, len, v_max, v_avg, scale, x_tics) {
  if (!values[i]) {
    return "";
  }
  var x_max = (len - 1) * x_tics;
  var y_offset = border_size;
  var y_max = font_size * 0.66;
  var x = 0;
  if (v_max > 0) {
    if (v_avg && v_avg > 0) {
      scale = min(scale, v_max / (2 * v_avg));
    }
    scale = (scale * y_max) / v_max;
  }
  var s = [format("m 0 0 n %f %f l ", x, y_max - scale * values[i])];
  i = ((i - 2) % len) + 1;
  for (var _ = 0; _ < len - 1; _ = _ + 1) {
    if (values[i]) {
      x = x - x_tics;
      s.push(format("%f %f ", x, y_max - scale * values[i]));
    }
    i = ((i - 2) % len) + 1;
  }
  s.push(format("%f %f %f %f", x, y_max, 0, y_max));
  var bg_box = format(
    "{\\bord%f}{\\3c&H%s&}{\\1c&H%s&}m 0 %f l %f %f %f 0 0 0",
    plot_bg_border_width,
    o.plot_bg_border_color,
    o.plot_bg_color,
    y_max,
    x_max,
    y_max,
    x_max
  );
  return format(
    "%s{\\rDefault}{\\pbo%f}{\\shad0}{\\alpha&H00}{\\p1}%s{\\p0}" +
      "{\\bord0}{\\1c&H%s}{\\p1}%s{\\p0}%s",
    o.prefix_sep,
    y_offset,
    bg_box,
    o.plot_color,
    s.join(""),
    text_style()
  );
}
function append(s, str, attr) {
  if (!str) {
    return false;
  }
  attr.prefix_sep = attr.prefix_sep || o.prefix_sep;
  attr.indent = attr.indent || o.indent;
  attr.nl = attr.nl || o.nl;
  attr.suffix = attr.suffix || "";
  attr.prefix = attr.prefix || "";
  attr.no_prefix_markup = attr.no_prefix_markup || false;
  attr.prefix = (attr.no_prefix_markup && attr.prefix) || bold(attr.prefix);
  var index = s.length + ((attr.nl === "" && 0) || 1);
  s[index] = s[index] || "";
  s[index] =
    s[index] +
    format(
      "%s%s%s%s%s%s",
      attr.nl,
      attr.indent,
      attr.prefix,
      attr.prefix_sep,
      no_ASS(str),
      attr.suffix
    );
  return true;
}
function append_property(s, prop, attr, excluded, cached) {
  excluded = excluded || { "": true };
  var ret;
  if (cached) {
    ret = get_property_cached(prop);
  } else {
    ret = mp.get_property_osd(prop);
  }
  if (!ret || excluded[ret]) {
    if (o.debug) {
      console.log("No value for property: " + prop);
    }
    return false;
  }
  return append(s, ret, attr);
}
function sorted_keys(t, comp_fn) {
  var keys = [];
  for (var k in Object.entries(t)) {
    keys.push(k);
  }
  table.sort(keys, comp_fn);
  return keys;
}
function scroll_hint(search) {
  var hint = format(
    "(hint: scroll with %s/%s",
    o.key_scroll_up,
    o.key_scroll_down
  );
  if (search) {
    hint = hint + (" and search with " + o.key_search);
  }
  hint = hint + ")";
  if (!o.use_ass) {
    return " " + hint;
  }
  return format(" {\\fs%s}%s{\\fs%s}", font_size * 0.66, hint, font_size);
}
function append_perfdata(header, s, dedicated_page) {
  var vo_p = mp.get_property_native("vo-passes");
  if (!vo_p) {
    return;
  }
  var last_s = [];
  var avg_s = [];
  var peak_s = [];
  var temp = Object.entries(vo_p);
  for (var frame in temp) {
	var data = temp[frame][1];
	last_s[frame] = 0;
	avg_s[frame] = 0;
	peak_s[frame] = 0;
    for (var kpass in data) {
	  var pass = data[kpass][1];
      last_s[frame] = last_s[frame] + pass["last"];
      avg_s[frame] = avg_s[frame] + pass["avg"];
      peak_s[frame] = peak_s[frame] + pass["peak"];
    }
  }
  function pp(i) {
    return format("%5d", i / 1000);
  }
  function p(n, m) {
    var i = 0;
    if (m > 0) {
      i = Number(n) / m;
    }
    var w = 700 * Math.sqrt(i) + 200;
    if (!o.use_ass) {
      var str = format("%3d%%", i * 100);
      return (w >= 700 && bold(str)) || str;
    }
    return format("{\\b%d}%3d%%{\\b0}", w, i * 100);
  }
  var font_small = (o.use_ass && format("{\\fs%s}", font_size * 0.66)) || "";
  var font_normal = (o.use_ass && format("{\\fs%s}", font_size)) || "";
  var font = (o.use_ass && format("{\\fn%s}", o.font)) || "";
  var font_mono = (o.use_ass && format("{\\fn%s}", o.font_mono)) || "";
  var indent = (o.use_ass && "\\h") || " ";
  var h = (dedicated_page && header) || s;
  h.push(
    format(
      "%s%s%s%s%s%s%s%s",
      (dedicated_page && "") || o.nl,
      (dedicated_page && "") || o.indent,
      bold("Frame Timings:"),
      o.prefix_sep,
      font_small,
      "(last/average/peak μs)",
      font_normal,
      (dedicated_page && scroll_hint()) || ""
    )
  );
  var temp_entries = entries(sorted_keys(vo_p));
  for (var kframe in temp_entries) {
	var frame = temp_entries[kframe][1];
    var data = vo_p[frame];
    var f = "%s%s%s%s%s / %s / %s %s%s%s%s%s%s";
    if (dedicated_page) {
      s.push(
        format("%s%s%s:", o.nl, o.indent, bold(frame.replaceAll("^%l", function(v) { return v.toUpperCase(); })))
      );
      for (var kpass in data) {
		var pass = data[kpass];
        s.push(
          format(
            f,
            o.nl,
            o.indent,
            o.indent,
            font_mono,
            pp(pass["last"]),
            pp(pass["avg"]),
            pp(pass["peak"]),
            o.prefix_sep + indent,
            p(pass["last"], last_s[frame]),
            font,
            o.prefix_sep,
            o.prefix_sep,
            pass["desc"]
          )
        );
        if (o.plot_perfdata && o.use_ass) {
          s[s.length] =
            s[s.length] +
            generate_graph(
              pass["samples"],
              pass["count"],
              pass["count"],
              pass["peak"],
              pass["avg"],
              0.9,
              0.25
            );
        }
      }
      s.push(
        format(
          f,
          o.nl,
          o.indent,
          o.indent,
          font_mono,
          pp(last_s[frame]),
          pp(avg_s[frame]),
          pp(peak_s[frame]),
          o.prefix_sep,
          bold("Total"),
          font,
          "",
          "",
          ""
        )
      );
    } else {
      s.push(
        format(
          f,
          o.nl,
          o.indent,
          o.indent,
          font_mono,
          pp(last_s[frame]),
          pp(avg_s[frame]),
          pp(peak_s[frame]),
          "",
          "",
          font,
          o.prefix_sep,
          o.prefix_sep,
          frame.replaceAll("^%l", function(v) { return v.toUpperCase(); })
        )
      );
    }
  }
}
var cmd_prefixes = {
  osd_auto: 1,
  no_osd: 1,
  osd_bar: 1,
  osd_msg: 1,
  osd_msg_bar: 1,
  raw: 1,
  sync: 1,
  "async": 1,
  expand_properties: 1,
  repeatable: 1,
  nonrepeatable: 1,
  nonscalable: 1,
  set: 1,
  add: 1,
  multiply: 1,
  toggle: 1,
  cycle: 1,
  cycle_values: 1,
  "!reverse": 1,
  change_list: 1,
};
var name_prefixes = {
  define: 1,
  "delete": 1,
  enable: 1,
  disable: 1,
  dump: 1,
  write: 1,
  drop: 1,
  revert: 1,
  ab: 1,
  hr: 1,
  secondary: 1,
  current: 1,
};

function cmd_subject(cmd) {
    cmd = cmd.replace(/;.*/, '').replace(/-/g, '_');
    var TOKEN = '^\\s*[\'"]?([\\w_!]*)';
    var tok, sname, subw;

    do {
        var match = cmd.match(new RegExp(TOKEN + '[\'"]?(.*)'));
        if (!match) break;
        tok = match[1];
        cmd = match[2];
    } while (cmd_prefixes[tok]);

    if (tok === "script_message_to") {
        var match = cmd.match(new RegExp(TOKEN));
        sname = match ? match[1] : null;
    } else if (tok === "script_binding") {
        var match = cmd.match(new RegExp(TOKEN + '/'));
        sname = match ? match[1] : null;
    }
    
    if (sname && sname !== "") {
        return "script: " + sname;
    }

    var remaining = tok;
    do {
        var underscorePos = remaining.indexOf('_');
        if (underscorePos === -1) {
            subw = remaining;
            remaining = "";
        } else {
            subw = remaining.substring(0, underscorePos);
            remaining = remaining.substring(underscorePos + 1);
        }
    } while (remaining !== "" && name_prefixes[subw]);
    
    return subw.length > 1 ? subw : "[unknown]";
}

/**
 * Calculates the display width of a key name in terminal cells.
 * Key names are valid UTF-8, with ASCII 7-bit characters except possibly the last/only codepoint.
 * We count codepoints and ignore wcwidth. No need for grapheme clusters.
 * The error for alignment is at most one cell (if last CP is double-width).
 * 
 * @param {string} k - The key name string
 * @returns {number} - The number of terminal cells the key name occupies
 */
function keyname_cells(k) {
    var klen = k.length;
    if (klen > 1 && k.charCodeAt(klen - 1) >= 0x80) {
        do {
            klen--;
        } while (klen > 1 && k.charCodeAt(klen - 1) < 0xC0);
    }
    return klen;
}

/**
 * Splits a string into an array using a separator pattern
 * @param {string} str - The string to split
 * @param {string|RegExp} pat - The separator pattern (string or RegExp)
 * @param {boolean} [plain=false] - Whether to treat pat as a plain string (default false - pat is a pattern)
 * @returns {string[]} Array of split parts
 */
function split(str, pat, plain) {
	if (plain == undefined || plain == null) {
		plain = false;
	}
    var init = 0;
    var result = [];
    var i = 0;

    var separator = plain ? pat : new RegExp(pat);
    
    while (true) {
        var match = str.slice(init).match(separator);
        if (!match) {
            result[i] = str.slice(init);
            break;
        }
        
        var matchIndex = match.index + init;
        result[i] = str.slice(init, matchIndex);
        i++;
        init = matchIndex + match[0].length;
    }
    
    return result;
}

function get_kbinfo_lines() {
  var bindings = mp.get_property_native("input-bindings", []);
  var active = [];
  var bindings_entries = Object.entries(bindings);
  for (var kbind in bindings_entries) {
	var bind = bindings_entries[kbind][1];
    if (
      bind.priority >= 0 &&
      (!active[bind.key] ||
        (active[bind.key].is_weak && !bind.is_weak) ||
        (bind.is_weak === active[bind.key].is_weak &&
          bind.priority > active[bind.key].priority)) &&
      find(bind.cmd, "script-binding stats/__forced_", 1, true).length == 0 &&
      bind.section !== "input_forced_console" &&
      (searched_text === undefined ||
        find((bind.key + (bind.cmd + (bind.comment || ""))).toLowerCase(), searched_text, 1, true).length == 0)
    ) {
      active[bind.key] = bind;
    }
  }
  var ordered = [];
  var kspaces = "";
  var active_entries = Object.entries(active);
  for (var kbind in active_entries) {
	var bind = active_entries[kbind][1];
    bind.subject = cmd_subject(bind.cmd);
    if (bind.subject !== "ignore") {
      ordered.push(bind);
      //bind.mods = bind.key.find("(.*)%+.")[2];
      //bind.mods_count = bind.key.gsub("%+.", "")[1];
      if (bind.key.length > kspaces.length) {
        kspaces = kspaces.replace(" ", bind.key.length);
      }
    }
  }
  function align_right(key) {
    return kspaces.substring(keyname_cells(key)) + key;
  }
  ordered.sort(function (a, b) {
    if (a.subject !== b.subject) {
      return a.subject < b.subject;
    } else if (a.mods_count !== b.mods_count) {
      return a.mods_count < b.mods_count;
    } else if (a.mods !== b.mods) {
      return a.mods < b.mods;
    } else if (a.key.length !== b.key.length) {
      return a.key.length < b.key.length;
    } else if (a.key.toLowerCase() !== b.key.toLowerCase()) {
      return a.key.toLowerCase() < b.key.toLowerCase();
    } else {
      return a.key > b.key;
    }
  });
  var LTR = String.fromCharCode(226, 128, 142);
  var term = !o.use_ass;
  var kpre = (term && "") || format("{\\q2\\fn%s}%s", o.font_mono, LTR);
  var kpost = (term && " ") || format(" {\\fn%s}", o.font);
  var spre =
    (term && kspaces + "   ") ||
    format(
      "{\\q2\\fn%s}%s   {\\fn%s}{\\fs%d\\u1}",
      o.font_mono,
      kspaces,
      o.font,
      1.3 * font_size
    );
  var spost = (term && "") || format("{\\u0\\fs%d}%s", font_size, text_style());
  var info_lines = [];
  var subject = undefined;
  for (var kbind in ordered) {
	var bind = ordered[kbind];
    if (bind.subject !== subject) {
      subject = bind.subject;
      append(info_lines, "", []);
      append(info_lines, "", { prefix: spre + (subject + spost) });
    }
    if (bind.comment) {
      bind.cmd = bind.cmd + ("  # " + bind.comment);
    }
    append(info_lines, bind.cmd, {
      prefix: kpre + (no_ASS(align_right(bind.key)) + kpost),
    });
  }
  return info_lines;
}
function append_general_perfdata(s) {
  var temp_entries = entries(mp.get_property_native("perf-info") || []);
  for (var i in temp_entries) {
	var data = temp_entries[i][1];
    append(s, data.text || data.value, {
      prefix: "[" + (String(i) + ("] " + (data.name + ":"))),
    });
    if (o.plot_perfdata && o.use_ass && data.value) {
      var buf = perf_buffers[data.name];
      if (!buf) {
        buf = { s: 0, pos: 1, len: 50, max: 0 };
        perf_buffers[data.name] = buf;
      }
      graph_add_value(buf, data.value);
      s[s.length] =
        s[s.length] +
        generate_graph(buf.s, buf.pos, buf.len, buf.max, undefined, 0.8, 1);
    }
  }
}
function append_display_sync(s) {
  if (!mp.get_property_bool("display-sync-active", false)) {
    return;
  }
  var vspeed = append_property(s, "video-speed-correction", { prefix: "DS:" });
  if (vspeed) {
    append_property(s, "audio-speed-correction", {
      prefix: "/",
      nl: "",
      indent: " ",
      prefix_sep: " ",
      no_prefix_markup: true,
    });
  } else {
    append_property(s, "audio-speed-correction", {
      prefix: "DS:" + (o.prefix_sep + " - / "),
      prefix_sep: "",
    });
  }
  append_property(s, "mistimed-frame-count", {
    prefix: "Mistimed:",
    nl: "",
    indent: o.prefix_sep + o.prefix_sep,
  });
  append_property(s, "vo-delayed-frame-count", {
    prefix: "Delayed:",
    nl: "",
    indent: o.prefix_sep + o.prefix_sep,
  });
  if (
    !display_timer.oneshot &&
    (o.plot_vsync_ratio || o.plot_vsync_jitter) &&
    o.use_ass
  ) {
    var ratio_graph = "";
    var jitter_graph = "";
    if (o.plot_vsync_ratio) {
      ratio_graph = generate_graph(
        vsratio_buf.s,
        vsratio_buf.pos,
        vsratio_buf.len,
        vsratio_buf.max,
        undefined,
        0.8,
        1
      );
    }
    if (o.plot_vsync_jitter) {
      jitter_graph = generate_graph(
        vsjitter_buf.s,
        vsjitter_buf.pos,
        vsjitter_buf.len,
        vsjitter_buf.max,
        undefined,
        0.8,
        1
      );
    }
    append_property(s, "vsync-ratio", {
      prefix: "VSync Ratio:",
      suffix: o.prefix_sep + ratio_graph,
    });
    append_property(s, "vsync-jitter", {
      prefix: "VSync Jitter:",
      suffix: o.prefix_sep + jitter_graph,
    });
  } else {
    var vr = append_property(s, "vsync-ratio", { prefix: "VSync Ratio:" });
    append_property(s, "vsync-jitter", {
      prefix: "VSync Jitter:",
      nl: (vr && "") || o.nl,
      indent: vr && o.prefix_sep + o.prefix_sep,
    });
  }
}
function append_filters(s, prop, prefix) {
  var length = 0;
  var filters = [];
  var filter_entries = entries(mp.get_property_native(prop, []));
  for (var keyf in filter_entries) {
	var f = filter_entries[keyf];
    var n = f.name;
    if (f.enabled !== undefined && !f.enabled) {
      n = n + " (disabled)";
    }
    if (f.label !== undefined) {
      n = "@" + (f.label + (": " + n));
    }
    var p = [];
	var sorted_keys_list = sorted_keys(f.params);
    for (var skey in sorted_keys_list) {
	  var key = sorted_keys_list[skey];
      p.push(key + ("=" + f.params[key]));
    }
    if (p.length > 0) {
      p = " [" + (p.join(" ") + "]");
    } else {
      p = "";
    }
    length = length + n.len() + p.len();
    filters.push(no_ASS(n) + it(no_ASS(p)));
  }
  if (filters.length > 0) {
    var ret;
    if (length < o.filter_params_max_length) {
      ret = filters.join(", ");
    } else {
      var sep = o.nl + (o.indent + o.indent);
      ret = sep + filters.join(sep);
    }
    s.push(o.nl + (o.indent + (bold(prefix) + (o.prefix_sep + ret))));
  }
}
function add_header(s) {
  s.push(text_style());
}
function add_file(s, print_cache, print_tags) {
  append(s, "", { prefix: "File:", nl: "", indent: "" });
  append_property(s, "filename", { prefix_sep: "", nl: "", indent: "" });
  if (mp.get_property_osd("filename") !== mp.get_property_osd("media-title")) {
    append_property(s, "media-title", { prefix: "Title:" });
  }
  if (print_tags) {
    var tags = mp.get_property_native("display-tags");
    var tags_displayed = 0;
    for (var ktag in tags) {
	  var tag = tags[ktag];
      var value = mp.get_property("metadata/by-key/" + tag);
      if (
        tag !== "Title" &&
        tags_displayed < o.file_tag_max_count &&
        value &&
        value.len() < o.file_tag_max_length
      ) {
        append(s, value, { prefix: function(str) { return str.replaceAll(tag, "_", " ") + ":"; } });
        tags_displayed = tags_displayed + 1;
      }
    }
  }
  var editions = mp.get_property_number("editions");
  var edition = mp.get_property_number("current-edition");
  var ed_cond = edition && editions > 1;
  if (ed_cond) {
    append_property(s, "edition-list/" + (String(edition) + "/title"), {
      prefix: "Edition:",
    });
    append_property(s, "edition-list/count", {
      prefix: "(" + (String(edition + 1) + "/"),
      suffix: ")",
      nl: "",
      indent: " ",
      prefix_sep: " ",
      no_prefix_markup: true,
    });
  }
  var ch_index = mp.get_property_number("chapter");
  if (ch_index && ch_index >= 0) {
    append_property(s, "chapter-list/" + (String(ch_index) + "/title"), {
      prefix: "Chapter:",
      nl: (ed_cond && "") || o.nl,
    });
    append_property(s, "chapter-list/count", {
      prefix: "(" + (String(ch_index + 1) + " /"),
      suffix: ")",
      nl: "",
      indent: " ",
      prefix_sep: " ",
      no_prefix_markup: true,
    });
  }
  var fs = append_property(s, "file-size", { prefix: "Size:" });
  append_property(s, "file-format", {
    prefix: "Format/Protocol:",
    nl: (fs && "") || o.nl,
    indent: fs && o.prefix_sep + o.prefix_sep,
  });
  if (!print_cache) {
    return;
  }
  var demuxer_cache = mp.get_property_native("demuxer-cache-state", []);
  if (demuxer_cache["fw-bytes"]) {
    demuxer_cache = demuxer_cache["fw-bytes"];
  } else {
    demuxer_cache = 0;
  }
  var demuxer_secs = mp.get_property_number("demuxer-cache-duration", 0);
  if (demuxer_cache + demuxer_secs > 0) {
    append(s, utils.format_bytes_humanized(demuxer_cache), {
      prefix: "Total Cache:",
    });
    append(s, format("%.1f", demuxer_secs), {
      prefix: "(",
      suffix: " sec)",
      nl: "",
      no_prefix_markup: true,
      prefix_sep: "",
      indent: o.prefix_sep,
    });
  }
}
function crop_noop(w, h, r) {
  return (
    r["crop-x"] === 0 &&
    r["crop-y"] === 0 &&
    r["crop-w"] === w &&
    r["crop-h"] === h
  );
}
function crop_equal(r, ro) {
  return (
    r["crop-x"] === ro["crop-x"] &&
    r["crop-y"] === ro["crop-y"] &&
    r["crop-w"] === ro["crop-w"] &&
    r["crop-h"] === ro["crop-h"]
  );
}
function append_resolution(s, r, prefix, w_prop, h_prop, video_res) {
  if (!r) {
    return;
  }
  w_prop = w_prop || "w";
  h_prop = h_prop || "h";
  if (append(s, r[w_prop], { prefix: prefix })) {
    append(s, r[h_prop], {
      prefix: "x",
      nl: "",
      indent: " ",
      prefix_sep: " ",
      no_prefix_markup: true,
    });
    if (r["aspect"] !== undefined && !video_res) {
      append(s, format("%.2f:1", r["aspect"]), {
        prefix: "",
        nl: "",
        indent: "",
        no_prefix_markup: true,
      });
      append(s, r["aspect-name"], {
        prefix: "(",
        suffix: ")",
        nl: "",
        indent: " ",
        prefix_sep: "",
        no_prefix_markup: true,
      });
    }
    if (r["sar"] !== undefined && video_res) {
      append(s, format("%.2f:1", r["sar"]), {
        prefix: "",
        nl: "",
        indent: "",
        no_prefix_markup: true,
      });
      append(s, r["sar-name"], {
        prefix: "(",
        suffix: ")",
        nl: "",
        indent: " ",
        prefix_sep: "",
        no_prefix_markup: true,
      });
    }
    if (r["s"]) {
      append(s, format("%.2f", r["s"]), {
        prefix: "(",
        suffix: "x)",
        nl: "",
        indent: o.prefix_sep,
        prefix_sep: "",
        no_prefix_markup: true,
      });
    }
    if (r["crop-w"] && (!video_res || !crop_noop(r[w_prop], r[h_prop], r))) {
      append(
        s,
        format(
          "[x: %d, y: %d, w: %d, h: %d]",
          r["crop-x"],
          r["crop-y"],
          r["crop-w"],
          r["crop-h"]
        ),
        { prefix: "", nl: "", indent: "", no_prefix_markup: true }
      );
    }
  }
}
function pq_eotf(x) {
  if (!x) {
    return x;
  }
  var PQ_M1 = ((2610 / 4096) * 1) / 4;
  var PQ_M2 = (2523 / 4096) * 128;
  var PQ_C1 = 3424 / 4096;
  var PQ_C2 = (2413 / 4096) * 32;
  var PQ_C3 = (2392 / 4096) * 32;
  x = x ^ (1 / PQ_M2);
  x = max(x - PQ_C1, 0) / (PQ_C2 - PQ_C3 * x);
  x = x ^ (1 / PQ_M1);
  x = x * 10000;
  return x;
}
function append_hdr(s, hdr, video_out) {
  if (!hdr) {
    return;
  }
  function should_show(val) {
    return val && val !== 203 && val > 0;
  }
  var display_prefix = (video_out && "Display:") || "Mastering display:";
  var indent = "";
  if (should_show(hdr["max-cll"]) || should_show(hdr["max-luma"])) {
    append(s, "", { prefix: "HDR10:" });
    if (hdr["min-luma"] && should_show(hdr["max-luma"])) {
      hdr["min-luma"] = (hdr["min-luma"] <= 0.000001 && 0) || hdr["min-luma"];
      append(s, format("%.2g / %.0f", hdr["min-luma"], hdr["max-luma"]), {
        prefix: display_prefix,
        suffix: " cd/m²",
        nl: "",
        indent: indent,
      });
      indent = o.prefix_sep + o.prefix_sep;
    }
    if (should_show(hdr["max-cll"])) {
      append(s, hdr["max-cll"], {
        prefix: "MaxCLL:",
        suffix: " cd/m²",
        nl: "",
        indent: indent,
      });
      indent = o.prefix_sep + o.prefix_sep;
    }
    if (hdr["max-fall"] && hdr["max-fall"] > 0) {
      append(s, hdr["max-fall"], {
        prefix: "MaxFALL:",
        suffix: " cd/m²",
        nl: "",
        indent: indent,
      });
    }
  }
  indent = o.prefix_sep + o.prefix_sep;
  if (
    hdr["scene-max-r"] ||
    hdr["scene-max-g"] ||
    hdr["scene-max-b"] ||
    hdr["scene-avg"]
  ) {
    append(s, "", { prefix: "HDR10+:" });
    append(
      s,
      format(
        "%.1f / %.1f / %.1f",
        hdr["scene-max-r"] || 0,
        hdr["scene-max-g"] || 0,
        hdr["scene-max-b"] || 0
      ),
      { prefix: "MaxRGB:", suffix: " cd/m²", nl: "", indent: "" }
    );
    append(s, format("%.1f", hdr["scene-avg"] || 0), {
      prefix: "Avg:",
      suffix: " cd/m²",
      nl: "",
      indent: indent,
    });
  }
  if (hdr["max-pq-y"] && hdr["avg-pq-y"]) {
    append(s, "", { prefix: "PQ(Y):" });
    append(
      s,
      format(
        "%.2f cd/m² (%.2f%% PQ)",
        pq_eotf(hdr["max-pq-y"]),
        hdr["max-pq-y"] * 100
      ),
      { prefix: "Max:", nl: "", indent: "" }
    );
    append(
      s,
      format(
        "%.2f cd/m² (%.2f%% PQ)",
        pq_eotf(hdr["avg-pq-y"]),
        hdr["avg-pq-y"] * 100
      ),
      { prefix: "Avg:", nl: "", indent: indent }
    );
  }
}
function append_img_params(s, r, ro) {
  if (!r) {
    return;
  }
  append_resolution(s, r, "Resolution:", "w", "h", true);
  if (ro && (r["w"] !== ro["dw"] || r["h"] !== ro["dh"])) {
    if (ro["crop-w"] && (crop_noop(r["w"], r["h"], ro) || crop_equal(r, ro))) {
      ro["crop-w"] = undefined;
    }
    append_resolution(s, ro, "Output Resolution:", "dw", "dh");
  }
  var indent = o.prefix_sep + o.prefix_sep;
  r = ro || r;
  var pixel_format = r["hw-pixelformat"] || r["pixelformat"];
  append(s, pixel_format, { prefix: "Format:" });
  append(s, r["colorlevels"], { prefix: "Levels:", nl: "", indent: indent });
  if (r["chroma-location"] && r["chroma-location"] !== "unknown") {
    append(s, r["chroma-location"], {
      prefix: "Chroma Loc:",
      nl: "",
      indent: indent,
    });
  }
  append(s, r["colormatrix"], { prefix: "Colormatrix:" });
  if (
    r["prim-red-x"] ||
    r["prim-red-y"] ||
    r["prim-green-x"] ||
    r["prim-green-y"] ||
    r["prim-blue-x"] ||
    r["prim-blue-y"] ||
    r["prim-white-x"] ||
    r["prim-white-y"]
  ) {
    append(
      s,
      format(
        "[%.3f %.3f, %.3f %.3f, %.3f %.3f, %.3f %.3f]",
        r["prim-red-x"] || 0,
        r["prim-red-y"] || 0,
        r["prim-green-x"] || 0,
        r["prim-green-y"] || 0,
        r["prim-blue-x"] || 0,
        r["prim-blue-y"] || 0,
        r["prim-white-x"] || 0,
        r["prim-white-y"] || 0
      ),
      { prefix: "Primaries:", nl: "", indent: indent }
    );
    append(s, r["primaries"], {
      prefix: "in",
      nl: "",
      indent: " ",
      prefix_sep: " ",
      no_prefix_markup: true,
    });
  } else {
    append(s, r["primaries"], { prefix: "Primaries:", nl: "", indent: indent });
  }
  append(s, r["gamma"], { prefix: "Transfer:", nl: "", indent: indent });
}
function append_fps(s, prop, eprop) {
  var fps = mp.get_property_osd(prop);
  var efps = mp.get_property_osd(eprop);
  var single = eprop === "" || (fps !== "" && efps !== "" && fps === efps);
  var unit = (prop === "display-fps" && " Hz") || " fps";
  var suffix = (single && "") || " (specified)";
  var esuffix = (single && "") || " (estimated)";
  var prefix = (prop === "display-fps" && "Refresh Rate:") || "Frame Rate:";
  var nl = o.nl;
  var indent = o.indent;
  if (fps !== "" && append(s, fps, { prefix: prefix, suffix: unit + suffix })) {
    prefix = "";
    nl = "";
    indent = "";
  }
  if (!single && efps !== "") {
    append(s, efps, {
      prefix: prefix,
      suffix: unit + esuffix,
      nl: nl,
      indent: indent,
    });
  }
}
function add_video_out(s) {
  var vo = mp.get_property_native("current-vo");
  if (!vo) {
    return;
  }
  append(s, "", { prefix: "Display:", nl: o.nl + o.nl, indent: "" });
  append(s, vo, { prefix_sep: "", nl: "", indent: "" });
  append_property(
    s,
    "display-names",
    {
      prefix_sep: "",
      prefix: "(",
      suffix: ")",
      no_prefix_markup: true,
      nl: "",
      indent: " ",
    },
    undefined,
    true
  );
  append(s, mp.get_property_native("current-gpu-context"), {
    prefix: "Context:",
    nl: "",
    indent: o.prefix_sep + o.prefix_sep,
  });
  append_property(s, "avsync", { prefix: "A-V:" });
  append_fps(s, "display-fps", "estimated-display-fps");
  if (
    append_property(s, "decoder-frame-drop-count", {
      prefix: "Dropped Frames:",
      suffix: " (decoder)",
    })
  ) {
    append_property(s, "frame-drop-count", {
      suffix: " (output)",
      nl: "",
      indent: "",
    });
  }
  append_display_sync(s);
  append_perfdata(undefined, s, false);
  if (mp.get_property_native("deinterlace-active")) {
    append_property(s, "deinterlace", { prefix: "Deinterlacing:" });
  }
  var scale = undefined;
  if (!mp.get_property_native("fullscreen")) {
    scale = get_property_cached("current-window-scale");
  }
  var od = mp.get_property_native("osd-dimensions");
  var rt = mp.get_property_native("video-target-params");
  var r = rt || [];
  r["s"] = scale;
  r["crop-x"] = od["ml"];
  r["crop-y"] = od["mt"];
  r["crop-w"] = od["w"] - od["ml"] - od["mr"];
  r["crop-h"] = od["h"] - od["mt"] - od["mb"];
  if (!rt) {
    r["w"] = r["crop-w"];
    r["h"] = r["crop-h"];
    append_resolution(s, r, "Resolution:", "w", "h", true);
    return;
  }
  append_img_params(s, r);
  append_hdr(s, r, true);
}
function add_video(s) {
  var r = mp.get_property_native("video-params");
  var ro = mp.get_property_native("video-out-params");
  if (!r) {
    r = ro;
  }
  if (!r) {
    return;
  }
  var track = mp.get_property_native("current-tracks/video");
  if (track) {
    append(s, "", {
      prefix: (track.image && "Image:") || "Video:",
      nl: o.nl + o.nl,
      indent: "",
    });
    append(s, track["codec-desc"], { prefix_sep: "", nl: "", indent: "" });
    append(s, track["codec-profile"], {
      prefix: "[",
      nl: "",
      indent: " ",
      prefix_sep: "",
      no_prefix_markup: true,
      suffix: "]",
    });
    if (track["codec"] !== track["decoder"]) {
      append(s, track["decoder"], {
        prefix: "[",
        nl: "",
        indent: " ",
        prefix_sep: "",
        no_prefix_markup: true,
        suffix: "]",
      });
    }
    append_property(
      s,
      "hwdec-current",
      {
        prefix: "HW:",
        nl: "",
        indent: o.prefix_sep + o.prefix_sep,
        no_prefix_markup: false,
        suffix: "",
      },
      { no: true, "": true },
      true
    );
  }
  var has_prefix = false;
  if (o.show_frame_info) {
    if (append_property(s, "estimated-frame-number", { prefix: "Frame:" })) {
      append_property(s, "estimated-frame-count", {
        indent: " / ",
        nl: "",
        prefix_sep: "",
      });
      has_prefix = true;
    }
    var frame_info = mp.get_property_native("video-frame-info");
    if (frame_info && frame_info["picture-type"]) {
      var attrs = (has_prefix && {
        prefix: "(",
        suffix: ")",
        indent: " ",
        nl: "",
        prefix_sep: "",
        no_prefix_markup: true,
      }) || { prefix: "Picture Type:" };
      append(s, frame_info["picture-type"], attrs);
      has_prefix = true;
    }
    if (frame_info && frame_info["interlaced"]) {
      var attrs = (has_prefix && { indent: " ", nl: "", prefix_sep: "" }) || {
        prefix: "Picture Type:",
      };
      append(s, "Interlaced", attrs);
    }
    var timecodes = {
      "gop-timecode": "GOP",
      "smpte-timecode": "SMPTE",
      "estimated-smpte-timecode": "Estimated SMPTE",
    };
	var timecodes_entries = Object.entries(timecodes);
    for (var prop in timecodes_entries) {
	  var name = timecodes_entries[prop][1];
      if (frame_info && frame_info[prop]) {
        var attrs = (has_prefix && {
          prefix: name + " Timecode:",
          indent: o.prefix_sep + o.prefix_sep,
          nl: "",
        }) || { prefix: name + " Timecode:" };
        append(s, frame_info[prop], attrs);
        break;
      }
    }
  }
  if (mp.get_property_native("current-tracks/video/image") === false) {
    append_fps(s, "container-fps", "estimated-vf-fps");
  }
  append_img_params(s, r, ro);
  append_hdr(s, ro);
  append_property(s, "video-bitrate", { prefix: "Bitrate:" });
  append_filters(s, "vf", "Filters:");
}
function add_audio(s) {
  var r = mp.get_property_native("audio-params");
  var ro = mp.get_property_native("audio-out-params") || r;
  r = r || ro;
  if (!r) {
    return;
  }
  var merge = function (rr, rro, prop) {
    var a = rr[prop] || rro[prop];
    var b = rro[prop] || rr[prop];
    return ((a === b || a === undefined) && a) || a + (" ➜ " + b);
  };
  append(s, "", { prefix: "Audio:", nl: o.nl + o.nl, indent: "" });
  var track = mp.get_property_native("current-tracks/audio");
  if (track) {
    append(s, track["codec-desc"], { prefix_sep: "", nl: "", indent: "" });
    append(s, track["codec-profile"], {
      prefix: "[",
      nl: "",
      indent: " ",
      prefix_sep: "",
      no_prefix_markup: true,
      suffix: "]",
    });
    if (track["codec"] !== track["decoder"]) {
      append(s, track["decoder"], {
        prefix: "[",
        nl: "",
        indent: " ",
        prefix_sep: "",
        no_prefix_markup: true,
        suffix: "]",
      });
    }
  }
  append_property(s, "current-ao", {
    prefix: "AO:",
    nl: "",
    indent: o.prefix_sep + o.prefix_sep,
  });
  var dev = append_property(s, "audio-device", { prefix: "Device:" });
  var ao_mute = (mp.get_property_native("ao-mute") && " (Muted)") || "";
  append_property(s, "ao-volume", {
    prefix: "AO Volume:",
    suffix: "%" + ao_mute,
    nl: (dev && "") || o.nl,
    indent: dev && o.prefix_sep + o.prefix_sep,
  });
  if (Math.abs(mp.get_property_native("audio-delay")) > 0.000001) {
    append_property(s, "audio-delay", { prefix: "A-V delay:" });
  }
  var cc = append(s, merge(r, ro, "channel-count"), { prefix: "Channels:" });
  append(s, merge(r, ro, "format"), {
    prefix: "Format:",
    nl: (cc && "") || o.nl,
    indent: cc && o.prefix_sep + o.prefix_sep,
  });
  append(s, merge(r, ro, "samplerate"), {
    prefix: "Sample Rate:",
    suffix: " Hz",
  });
  append_property(s, "audio-bitrate", { prefix: "Bitrate:" });
  append_filters(s, "af", "Filters:");
}
function eval_ass_formatting() {
  o.use_ass = o.ass_formatting && has_vo_window();
  if (o.use_ass) {
    o.nl = o.ass_nl;
    o.indent = o.ass_indent;
    o.prefix_sep = o.ass_prefix_sep;
    o.b1 = o.ass_b1;
    o.b0 = o.ass_b0;
    o.it1 = o.ass_it1;
    o.it0 = o.ass_it0;
  } else {
    o.nl = o.no_ass_nl;
    o.indent = o.no_ass_indent;
    o.prefix_sep = o.no_ass_prefix_sep;
    o.b1 = o.no_ass_b1;
    o.b0 = o.no_ass_b0;
    o.it1 = o.no_ass_it1;
    o.it0 = o.no_ass_it0;
  }
}
function finalize_page(header, content, apply_scroll) {
  var term_height = mp.get_property_native("term-size/h", 24);
  var from = 1;
  var to = content.length;
  if (apply_scroll) {
    var max_content_lines =
      ((o.use_ass && 40) || term_height - 2) - header.length;
    var max_offset =
      (o.use_ass && content.length) || content.length - max_content_lines + 1;
    from = max(1, min(pages[curr_page].offset || 1, max_offset));
    to = min(content.length, from + max_content_lines - 1);
    pages[curr_page].offset = from;
  }
  var output = header.join("") + content.join("");
  if (!o.use_ass && o.term_clip) {
    var clip = mp.get_property("term-clip-cc");
    var t = split(output, "\n", true);
    output = clip + t.join("\n" + clip);
  }
  return [output, from];
}
function default_stats() {
  var stats = [];
  eval_ass_formatting();
  add_header(stats);
  add_file(stats, true, false);
  add_video_out(stats);
  add_video(stats);
  add_audio(stats);
  return finalize_page([], stats, false);
}
function vo_stats() {
  var header = [];
  var content = [];
  eval_ass_formatting();
  add_header(header);
  append_perfdata(header, content, true);
  header = [header.join("")];
  return finalize_page(header, content, true);
}
var kbinfo_lines = undefined;
function keybinding_info(after_scroll, bindlist) {
  var header = [];
  var page = pages[o.key_page_4];
  eval_ass_formatting();
  add_header(header);
  var prefix = (bindlist && page.desc) || page.desc + (":" + scroll_hint(true));
  append(header, "", { prefix: prefix, nl: "", indent: "" });
  header = [header.join("")];
  if (!kbinfo_lines || !after_scroll) {
    kbinfo_lines = get_kbinfo_lines();
  }
  return finalize_page(header, kbinfo_lines, !bindlist);
}
function float2rational(x) {
  var max_den = 100000;
  var m00 = 1;
  var m01 = 0;
  var m10 = 0;
  var m11 = 1;
  var a = Math.floor(x);
  var frac = x - a;
  while (m10 * a + m11 <= max_den) {
    var temp = m00 * a + m01;
    m01 = m00;
    m00 = temp;
    temp = m10 * a + m11;
    m11 = m10;
    m10 = temp;
    if (frac === 0) {
      break;
    }
    x = 1 / frac;
    a = Math.floor(x);
    frac = x - a;
  }
  return [m00, m10];
}
function add_track(c, t, i) {
  if (!t) {
    return;
  }
  var type =
    (t.image && "Image") || t["type"].substring(1, 1).toUpperCase() + t["type"].substring(2);
  append(c, "", { prefix: type + ":", nl: o.nl + o.nl, indent: "" });
  append(c, t["title"], { prefix_sep: "", nl: "", indent: "" });
  append(c, t["id"], { prefix: "ID:" });
  append(c, t["src-id"], {
    prefix: "Demuxer ID:",
    nl: "",
    indent: o.prefix_sep + o.prefix_sep,
  });
  append(c, t["program-id"], {
    prefix: "Program ID:",
    nl: "",
    indent: o.prefix_sep + o.prefix_sep,
  });
  append(c, t["ff-index"], {
    prefix: "FFmpeg Index:",
    nl: "",
    indent: o.prefix_sep + o.prefix_sep,
  });
  append(c, t["external-filename"], { prefix: "File:" });
  append(c, "", { prefix: "Flags:" });
  var flags = [
    "default",
    "forced",
    "dependent",
    "visual-impaired",
    "hearing-impaired",
    "image",
    "albumart",
    "external",
  ];
  var any = false;
  for (var kflag in flags) {
	var flag = flags[kflag];
    if (t[flag]) {
      append(c, flag, {
        prefix: (any && ", ") || "",
        nl: "",
        indent: "",
        prefix_sep: "",
      });
      any = true;
    }
  }
  if (!any) {
    c.pop();
  }
  if (append(c, t["codec-desc"], { prefix: "Format:" })) {
    append(c, t["codec-profile"], {
      prefix: "[",
      nl: "",
      indent: " ",
      prefix_sep: "",
      no_prefix_markup: true,
      suffix: "]",
    });
    if (t["codec"] !== t["decoder"]) {
      append(c, t["decoder"], {
        prefix: "[",
        nl: "",
        indent: " ",
        prefix_sep: "",
        no_prefix_markup: true,
        suffix: "]",
      });
    }
  }
  append(c, t["lang"], { prefix: "Language:" });
  append(c, t["demux-channel-count"], { prefix: "Channels:" });
  append(c, t["demux-channels"], { prefix: "Channel Layout:" });
  append(c, t["demux-samplerate"], { prefix: "Sample Rate:", suffix: " Hz" });
  function B(b) {
    return b && format("%.2f", b / 1024);
  }
  var bitrate = append(c, B(t["demux-bitrate"]), {
    prefix: "Bitrate:",
    suffix: " kbps",
  });
  append(c, B(t["hls-bitrate"]), {
    prefix: "HLS Bitrate:",
    suffix: " kbps",
    nl: (bitrate && "") || o.nl,
    indent: bitrate && o.prefix_sep + o.prefix_sep,
  });
  append_resolution(
    c,
    {
      w: t["demux-w"],
      h: t["demux-h"],
      "crop-x": t["demux-crop-x"],
      "crop-y": t["demux-crop-y"],
      "crop-w": t["demux-crop-w"],
      "crop-h": t["demux-crop-h"],
    },
    "Resolution:"
  );
  if (!t["image"] && t["demux-fps"]) {
    append_fps(c, "track-list/" + (i + "/demux-fps"), "");
  }
  append(c, t["demux-rotation"], { prefix: "Rotation:" });
  if (t["demux-par"]) {
    var f2r_result = float2rational(t["demux-par"]);
	var num = f2r_result[0];
	var den = f2r_result[1];
    append(c, format("%d:%d", num, den), {
      prefix: "Pixel Aspect Ratio:",
    });
  }
  var track_rg =
    t["replaygain-track-peak"] !== undefined ||
    t["replaygain-track-gain"] !== undefined;
  var album_rg =
    t["replaygain-album-peak"] !== undefined ||
    t["replaygain-album-gain"] !== undefined;
  if (track_rg || album_rg) {
    append(c, "", { prefix: "Replay Gain:" });
  }
  if (track_rg) {
    append(c, "", {
      prefix: "Track:",
      indent: o.indent + o.prefix_sep,
      prefix_sep: "",
    });
    append(c, t["replaygain-track-gain"], {
      prefix: "Gain:",
      suffix: " dB",
      nl: "",
      indent: o.prefix_sep,
    });
    append(c, t["replaygain-track-peak"], {
      prefix: "Peak:",
      suffix: " dB",
      nl: "",
      indent: o.prefix_sep,
    });
  }
  if (album_rg) {
    append(c, "", {
      prefix: "Album:",
      indent: o.indent + o.prefix_sep,
      prefix_sep: "",
    });
    append(c, t["replaygain-album-gain"], {
      prefix: "Gain:",
      suffix: " dB",
      nl: "",
      indent: o.prefix_sep,
    });
    append(c, t["replaygain-album-peak"], {
      prefix: "Peak:",
      suffix: " dB",
      nl: "",
      indent: o.prefix_sep,
    });
  }
  if (t["dolby-vision-profile"] || t["dolby-vision-level"]) {
    append(c, "", { prefix: "Dolby Vision:" });
    append(c, t["dolby-vision-profile"], {
      prefix: "Profile:",
      nl: "",
      indent: "",
    });
    append(c, t["dolby-vision-level"], {
      prefix: "Level:",
      nl: "",
      indent: (t["dolby-vision-profile"] && o.prefix_sep + o.prefix_sep) || "",
    });
  }
}
function track_info() {
  var h = [];
  var c = [];
  eval_ass_formatting();
  add_header(h);
  var desc = pages[o.key_page_5].desc;
  append(h, "", {
    prefix: format("%s:%s", desc, scroll_hint()),
    nl: "",
    indent: "",
  });
  h = [h.join("")];
  c.push(o.nl + o.nl);
  add_file(c, false, true);
  var track_entries = entries(mp.get_property_native("track-list"));
  for (var i in track_entries) {
	var track = track_entries[i][1];
    if (track["selected"]) {
      add_track(c, track, i - 1);
    }
  }
  return finalize_page(h, c, true);
}
function perf_stats() {
  var header = [];
  var content = [];
  eval_ass_formatting();
  add_header(header);
  var page = pages[o.key_page_0];
  append(header, "", {
    prefix: format("%s:%s", page.desc, scroll_hint()),
    nl: "",
    indent: "",
  });
  append_general_perfdata(content);
  header = [header.join("")];
  return finalize_page(header, content, true);
}
function opt_time(t) {
  if (typeof t === typeof 1.1) {
    return mp.format_time(t);
  }
  return "?";
}
function cache_stats() {
  var stats = [];
  eval_ass_formatting();
  add_header(stats);
  append(stats, "", { prefix: "Cache Info:", nl: "", indent: "" });
  var info = mp.get_property_native("demuxer-cache-state");
  if (info === undefined) {
    append(stats, "Unavailable.", []);
    return finalize_page([], stats, false);
  }
  var a = info["reader-pts"];
  var b = info["cache-end"];
  append(stats, opt_time(a) + (" - " + opt_time(b)), {
    prefix: "Packet Queue:",
  });
  var r = undefined;
  if (a !== undefined && b !== undefined) {
    r = b - a;
  }
  var r_graph = undefined;
  if (!display_timer.oneshot && o.use_ass && o.plot_cache) {
    r_graph = generate_graph(
      cache_ahead_buf.s,
      cache_ahead_buf.pos,
      cache_ahead_buf.len,
      cache_ahead_buf.max,
      undefined,
      0.8,
      1
    );
    r_graph = o.prefix_sep + r_graph;
  }
  append(stats, opt_time(r), { prefix: "Readahead:", suffix: r_graph });
  var state = "reading";
  var seek_ts = info["debug-seeking"];
  if (seek_ts !== undefined) {
    state = "seeking (to " + (mp.format_time(seek_ts) + ")");
  } else if (info["eof"] === true) {
    state = "eof";
  } else if (info["underrun"]) {
    state = "underrun";
  } else if (info["idle"] === true) {
    state = "inactive";
  }
  append(stats, state, { prefix: "State:" });
  var speed = info["raw-input-rate"] || 0;
  var speed_graph = undefined;
  if (!display_timer.oneshot && o.use_ass && o.plot_cache) {
    speed_graph = generate_graph(
      cache_speed_buf.s,
      cache_speed_buf.pos,
      cache_speed_buf.len,
      cache_speed_buf.max,
      undefined,
      0.8,
      1
    );
    speed_graph = o.prefix_sep + speed_graph;
  }
  append(stats, utils.format_bytes_humanized(speed) + "/s", {
    prefix: "Speed:",
    suffix: speed_graph,
  });
  append(stats, utils.format_bytes_humanized(info["total-bytes"]), {
    prefix: "Total RAM:",
  });
  append(stats, utils.format_bytes_humanized(info["fw-bytes"]), {
    prefix: "Forward RAM:",
  });
  var fc = info["file-cache-bytes"];
  if (fc !== undefined) {
    fc = utils.format_bytes_humanized(fc);
  } else {
    fc = "(disabled)";
  }
  append(stats, fc, { prefix: "Disk Cache:" });
  append(stats, info["debug-low-level-seeks"], { prefix: "Media Seeks:" });
  append(stats, info["debug-byte-level-seeks"], { prefix: "Stream Seeks:" });
  append(stats, "", { prefix: "Ranges:", nl: o.nl + o.nl, indent: "" });
  append(stats, (info["bof-cached"] && "yes") || "no", {
    prefix: "Start Cached:",
  });
  append(stats, (info["eof-cached"] && "yes") || "no", {
    prefix: "End Cached:",
  });
  var ranges = info["seekable-ranges"] || [];
  var ranges_entries = entries(ranges);
  for (var n in ranges_entries) {
	var range = ranges_entries[n][1];
    append(
      stats,
      mp.format_time(range["start"]) + (" - " + mp.format_time(range["end"])),
      { prefix: format("Range %s:", n) }
    );
  }
  return finalize_page([], stats, false);
}
function record_cache_stats() {
  var info = mp.get_property_native("demuxer-cache-state");
  if (info === undefined) {
    return;
  }
  var a = info["reader-pts"];
  var b = info["cache-end"];
  if (a !== undefined && b !== undefined) {
    graph_add_value(cache_ahead_buf, b - a);
  }
  graph_add_value(cache_speed_buf, info["raw-input-rate"] || 0);
}
cache_recorder_timer = new IntervalTimer(record_cache_stats, 0.25, false);
cache_recorder_timer.kill();
curr_page = o.key_page_1;
pages[o.key_page_1] = { idx: 1, f: default_stats, desc: "Default" };
pages[o.key_page_2] = {
    idx: 2,
    f: vo_stats,
    desc: "Extended Frame Timings",
    scroll: true,
};
pages[o.key_page_3] = { idx: 3, f: cache_stats, desc: "Cache Statistics" };
pages[o.key_page_4] = {
    idx: 4,
    f: keybinding_info,
    desc: "Active Key Bindings",
    scroll: true,
};
pages[o.key_page_5] = {
    idx: 5,
    f: track_info,
    desc: "Selected Tracks Info",
    scroll: true,
};
pages[o.key_page_0] = {
    idx: 0,
    f: perf_stats,
    desc: "Internal Performance Info",
    scroll: true,
};

function record_data(skip) {
  init_buffers();
  skip = max(skip, 0);
  var i = skip;
  return function () {
    if (i < skip) {
      i = i + 1;
      return;
    } else {
      i = 0;
    }
    if (o.plot_vsync_jitter) {
      var r = mp.get_property_number("vsync-jitter");
      if (r) {
        vsjitter_buf.pos = (vsjitter_buf.pos % vsjitter_buf.len) + 1;
        vsjitter_buf[vsjitter_buf.pos] = r;
        vsjitter_buf.max = max(vsjitter_buf.max, r);
      }
    }
    if (o.plot_vsync_ratio) {
      var r = mp.get_property_number("vsync-ratio");
      if (r) {
        vsratio_buf.pos = (vsratio_buf.pos % vsratio_buf.len) + 1;
        vsratio_buf[vsratio_buf.pos] = r;
        vsratio_buf.max = max(vsratio_buf.max, r);
      }
    }
  };
}
function print_page(page, after_scroll) {
  var ass_content = pages[page].f(after_scroll);
  if (o.persistent_overlay) {
    mp.set_osd_ass(0, 0, ass_content);
  } else {
    mp.osd_message(
      ((o.use_ass && ass_start) || "") + ass_content,
      (display_timer.oneshot && o.duration) || o.redraw_delay + 1
    );
  }
}
update_scale = function () {
  var scale_with_video;
  if (o.vidscale === "auto") {
    scale_with_video = mp.get_property_native("osd-scale-by-window");
  } else {
    scale_with_video = o.vidscale === "yes";
  }
  var scale = 288 / 720;
  var osd_height = mp.get_property_native("osd-height");
  if (!scale_with_video && osd_height > 0) {
    scale = 288 / osd_height;
  }
  font_size = o.font_size * scale;
  border_size = o.border_size * scale;
  shadow_x_offset = o.shadow_x_offset * scale;
  shadow_y_offset = o.shadow_y_offset * scale;
  plot_bg_border_width = o.plot_bg_border_width * scale;
  if (display_timer.is_enabled()) {
    print_page(curr_page);
  }
};
function clear_screen() {
  if (o.persistent_overlay) {
    mp.set_osd_ass(0, 0, "");
  } else {
    mp.osd_message("", 0);
  }
}
function scroll_delta(d) {
  if (display_timer.oneshot) {
    display_timer.kill();
    display_timer.resume();
  }
  pages[curr_page].offset = (pages[curr_page].offset || 1) + d;
  print_page(curr_page, true);
}
function scroll_up() {
  scroll_delta(-o.scroll_lines);
}
function scroll_down() {
  scroll_delta(o.scroll_lines);
}
function reset_scroll_offsets() {
  var pages_entries = Object.entries(pages);
  for (var kpage in pages_entries) {
	var page = pages_entries[kpage][1];
    page.offset = undefined;
  }
}
function bind_scroll() {
  if (!scroll_bound) {
    mp.add_forced_key_binding(
      o.key_scroll_up,
      "__forced_" + o.key_scroll_up,
      scroll_up,
      { repeatable: true }
    );
    mp.add_forced_key_binding(
      o.key_scroll_down,
      "__forced_" + o.key_scroll_down,
      scroll_down,
      { repeatable: true }
    );
    scroll_bound = true;
  }
}
function unbind_scroll() {
  if (scroll_bound) {
    mp.remove_key_binding("__forced_" + o.key_scroll_up);
    mp.remove_key_binding("__forced_" + o.key_scroll_down);
    scroll_bound = false;
  }
}
function filter_bindings() {
  input.get({
    prompt: "Filter bindings:",
    opened: function () {
      searched_text = "";
    },
    edited: function (text) {
      reset_scroll_offsets();
      searched_text = text.lower();
      print_page(curr_page);
      if (display_timer.oneshot) {
        display_timer.kill();
        display_timer.resume();
      }
    },
    closed: function () {
      searched_text = undefined;
      if (display_timer.is_enabled()) {
        print_page(curr_page);
        if (display_timer.oneshot) {
          display_timer.kill();
          display_timer.resume();
        }
      }
    },
    dont_bind_up_down: true,
  });
}
function bind_search() {
  mp.add_forced_key_binding(
    o.key_search,
    "__forced_" + o.key_search,
    filter_bindings
  );
}
function unbind_search() {
  mp.remove_key_binding("__forced_" + o.key_search);
}
function bind_exit() {
  if (!display_timer.oneshot) {
    mp.add_forced_key_binding(
      o.key_exit,
      "__forced_" + o.key_exit,
      function () {
        process_key_binding(false);
      }
    );
  }
}
function unbind_exit() {
  mp.remove_key_binding("__forced_" + o.key_exit);
}
function update_scroll_bindings(k) {
  if (pages[k].scroll) {
    bind_scroll();
  } else {
    unbind_scroll();
  }
  if (k === o.key_page_4) {
    bind_search();
  } else {
    unbind_search();
  }
}
function add_page_bindings() {
  function a(k) {
    return function () {
      reset_scroll_offsets();
      update_scroll_bindings(k);
      curr_page = k;
      print_page(k);
      if (display_timer.oneshot) {
        display_timer.kill();
        display_timer.resume();
      }
    };
  }
  for (var k in Object.entries(pages)) {
    mp.add_forced_key_binding(k, "__forced_" + k, a(k), { repeatable: true });
  }
  update_scroll_bindings(curr_page);
  bind_exit();
}
function remove_page_bindings() {
  for (var k in Object.entries(pages)) {
    mp.remove_key_binding("__forced_" + k);
  }
  unbind_scroll();
  unbind_search();
  unbind_exit();
}
process_key_binding = function (oneshot) {
  reset_scroll_offsets();
  if (display_timer.is_enabled()) {
    if (display_timer.oneshot && oneshot) {
      display_timer.kill();
      print_page(curr_page);
      display_timer.resume();
    } else if (!display_timer.oneshot && !oneshot) {
      display_timer.kill();
      cache_recorder_timer.pause();
      if (tm_viz_prev !== undefined) {
        mp.set_property_native("tone-mapping-visualize", tm_viz_prev);
        tm_viz_prev = undefined;
      }
      clear_screen();
      remove_page_bindings();
      if (recorder) {
        mp.unobserve_property(recorder);
        recorder = undefined;
      }
    }
  } else {
    if (!oneshot && (o.plot_vsync_jitter || o.plot_vsync_ratio)) {
      recorder = record_data(o.skip_frames);
      mp.observe_property("vsync-jitter", "none", recorder);
    }
    if (!oneshot && o.plot_tonemapping_lut) {
      tm_viz_prev = mp.get_property_native("tone-mapping-visualize");
      mp.set_property_native("tone-mapping-visualize", true);
    }
    if (!oneshot) {
      cache_ahead_buf = { s: 0, pos: 1, len: 50, max: 0 };
      cache_speed_buf = { s: 0, pos: 1, len: 50, max: 0 };
      cache_recorder_timer.resume();
    }
    display_timer.kill();
    display_timer.oneshot = oneshot;
    display_timer.timeout = ((oneshot && o.duration) || o.redraw_delay) * 1000;
    add_page_bindings();
    print_page(curr_page);
    display_timer.resume();
  }
};
display_timer = new IntervalTimer(function () {
  if (display_timer.oneshot) {
	  display_timer.kill();
    clear_screen();
    remove_page_bindings();
    if (searched_text) {
      input.terminate();
    }
  } else {
    print_page(curr_page);
  }
}, o.duration, true);
display_timer.kill();
mp.add_key_binding(
  undefined,
  "display-stats",
  function () {
    process_key_binding(true);
  },
  { repeatable: true }
);
mp.add_key_binding(
  undefined,
  "display-stats-toggle",
  function () {
    process_key_binding(false);
  },
  { repeatable: false }
);
var pages_entries = Object.entries(pages);

function callback_page(idx) {
  return function() {
    curr_page = idx;
    process_key_binding(true);
  }
}
function callback_page_toggle(idx) {
  return function() {
    curr_page = idx;
    process_key_binding(false);
  }
}

for (var k in pages_entries) {
  var page = pages_entries[k][1];
  var idx = page.idx;
  mp.add_key_binding(
    undefined,
    "display-page-" + idx,
    callback_page(idx),
    { repeatable: true }
  );
  mp.add_key_binding(
    undefined,
    "display-page-" + (idx + "-toggle"),
    callback_page_toggle(idx),
    { repeatable: false }
  );
}

mp.register_event("video-reconfig", function () {
  if (display_timer.is_enabled() && !display_timer.oneshot) {
    print_page(curr_page);
  }
});
if (o.bindlist !== "no") {
  mp.set_property("msg-level", "all=no,statusline=status");
  mp.set_property("term-osd", "force");
  mp.set_property_bool("msg-module", false);
  mp.set_property_bool("msg-time", false);
  setTimeout(function () {
    if (o.bindlist.substring(1, 1) === "-") {
      o.no_ass_b0 = "";
      o.no_ass_b1 = "";
    }
    o.ass_formatting = false;
    o.no_ass_indent = " ";
    mp.osd_message(keybinding_info(false, true));
    setTimeout(function () {
      mp.command("flush-status-line no");
      mp.command("quit");
    }, 0);
  }, 0);
}
mp.observe_property("osd-height", "native", update_scale);
mp.observe_property("osd-scale-by-window", "native", update_scale);
function update_property_cache(name, value) {
  property_cache[name] = value;
}
mp.observe_property("current-window-scale", "native", update_property_cache);
mp.observe_property("display-names", "string", update_property_cache);
mp.observe_property("hwdec-current", "string", update_property_cache);
