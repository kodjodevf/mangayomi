var aniyomi = {};
// UI
aniyomi.show_text = function show_text(text) {
    mp.set_property("user-data/aniyomi/show_text", text)
}
aniyomi.hide_ui = function hide_ui() {
    mp.set_property("user-data/aniyomi/toggle_ui", "hide")
}
aniyomi.show_ui = function show_ui() {
    mp.set_property("user-data/aniyomi/toggle_ui", "show")
}
aniyomi.toggle_ui = function toggle_ui() {
    mp.set_property("user-data/aniyomi/toggle_ui", "toggle")
}
aniyomi.show_subtitle_settings = function show_subtitle_settings() {
    mp.set_property("user-data/aniyomi/show_panel", "subtitle_settings")
}
aniyomi.show_subtitle_delay = function show_subtitle_delay() {
    mp.set_property("user-data/aniyomi/show_panel", "subtitle_delay")
}
aniyomi.show_audio_delay = function show_audio_delay() {
    mp.set_property("user-data/aniyomi/show_panel", "audio_delay")
}
aniyomi.show_video_filters = function show_video_filters() {
    mp.set_property("user-data/aniyomi/show_panel", "video_filters")
}
aniyomi.show_software_keyboard = function show_software_keyboard() {
    mp.set_property("user-data/aniyomi/software_keyboard", "show")
}
aniyomi.hide_software_keyboard = function hide_software_keyboard() {
    mp.set_property("user-data/aniyomi/software_keyboard", "hide")
}
aniyomi.toggle_software_keyboard = function toggle_software_keyboard() {
    mp.set_property("user-data/aniyomi/software_keyboard", "toggle")
}
// Custom buttons
aniyomi.set_button_title = function set_button_title(text) {
    mp.set_property("user-data/aniyomi/set_button_title", text)
}
aniyomi.reset_button_title = function reset_button_title() {
    mp.set_property("user-data/aniyomi/reset_button_title", "unused")
}
aniyomi.hide_button = function hide_button() {
    mp.set_property("user-data/aniyomi/toggle_button", "hide")
}
aniyomi.show_button = function show_button() {
    mp.set_property("user-data/aniyomi/toggle_button", "show")
}
aniyomi.toggle_button = function toggle_button() {
    mp.set_property("user-data/aniyomi/toggle_button", "toggle")
}
// Controls
aniyomi.previous_episode = function previous_episode() {
    mp.set_property("user-data/aniyomi/switch_episode", "p")
}
aniyomi.next_episode = function next_episode() {
    mp.set_property("user-data/aniyomi/switch_episode", "n")
}
aniyomi.pause = function pause() {
    mp.set_property("user-data/aniyomi/pause", "pause")
}
aniyomi.unpause = function unpause() {
    mp.set_property("user-data/aniyomi/pause", "unpause")
}
aniyomi.pauseunpause = function pauseunpause() {
    mp.set_property("user-data/aniyomi/pause", "pauseunpause")
}
aniyomi.seek_by = function seek_by(value) {
    mp.set_property("user-data/aniyomi/seek_by", value)
}
aniyomi.seek_to = function seek_to(value) {
    mp.set_property("user-data/aniyomi/seek_to", value)
}
aniyomi.seek_by_with_text = function seek_by_with_text(value, text) {
    mp.set_property("user-data/aniyomi/seek_by_with_text", value + "|" + text)
}
aniyomi.seek_to_with_text = function seek_to_with_text(value, text) {
    mp.set_property("user-data/aniyomi/seek_to_with_text", value + "|" + text)
}
aniyomi.int_picker = function int_picker(title, name_format, start, stop, step, property) {
    mp.set_property("user-data/aniyomi/launch_int_picker", title + "|" + name_format +  "|" + start + "|" + stop + "|" + step + "|" + property)
}
// Legacy
aniyomi.left_seek_by = function left_seek_by(value) {
    aniyomi.seek_by(-value)
}
aniyomi.right_seek_by = function right_seek_by(value) {
    aniyomi.seek_by(value)
}
module.exports = aniyomi;
